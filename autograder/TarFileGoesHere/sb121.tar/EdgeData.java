import java.util.*;

public class EdgeData {
        
    public int latency;
    public int type;

    public EdgeData(int type) {
        this.type = type;
    }

}